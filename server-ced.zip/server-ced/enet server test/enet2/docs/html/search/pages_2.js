var searchData=
[
  ['frequently_20answered_20questions',['Frequently Answered Questions',['../FAQ.html',1,'']]],
  ['features_20and_20architecture',['Features and Architecture',['../Features.html',1,'']]]
];
